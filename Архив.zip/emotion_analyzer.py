from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch
import torch.nn.functional as F

class EmotionAnalyzer:
    def __init__(self):
        self.tokenizer = AutoTokenizer.from_pretrained("MaxKazak/ruBert-base-russian-emotion-detection")
        self.model = AutoModelForSequenceClassification.from_pretrained("MaxKazak/ruBert-base-russian-emotion-detection")
        self.model.eval()
        self.id2label = self.model.config.id2label

    def analyze(self, text: str):
        inputs = self.tokenizer(text, return_tensors="pt", truncation=True, padding=True)
        with torch.no_grad():
            outputs = self.model(**inputs)
        scores = F.softmax(outputs.logits, dim=1).squeeze()
        max_idx = torch.argmax(scores).item()
        return self.id2label[max_idx], scores[max_idx].item()
